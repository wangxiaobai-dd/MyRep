#include <iostream>
#include <string>
#include "DynamicTest.h"
#include "UserMain.h"

using namespace std;

NF_EXPORT void test(User* user)
{
	//cout << "4" << endl;
	user->a = 4;
}


#ifndef NF_USER_H
#define NF_USER_H
struct User
{
	int a = 0;
};
#endif
